DROP DATABASE IF EXISTS projetoIntegrador;
CREATE DATABASE projetoIntegrador;
USE projetoIntegrador;

CREATE TABLE usuario (
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
login VARCHAR(40),
senha VARCHAR(20),
nomeCompleto VARCHAR(60),
cpf CHAR(13),
email VARCHAR(50),
telefonePrincipal CHAR(11)
)engine InnoDB;

CREATE TABLE passeProprio (
idPasse INT NOT NULL PRIMARY KEY,
idUsuario INT NOT NULL,
nomePasse VARCHAR(30),
saldo INT NOT NULL,
FOREIGN KEY (idUsuario) REFERENCES usuario (id)
)engine InnoDB;

CREATE TABLE passeAlheio (
idUsuario INT NOT NULL PRIMARY KEY,
nomeDono VARCHAR(40),
nomePasse VARCHAR(40),
saldo INT NOT NULL,
FOREIGN KEY (idUsuario) REFERENCES usuario (id)
)engine InnoDB;

CREATE TABLE metodoDePagamento (
id INT NOT NULL PRIMARY KEY,
nomeProprietario VARCHAR(40),
nomeMetodo VARCHAR(30),
numeroCartao CHAR(19),
dataValidade CHAR(5),
FOREIGN KEY (id) REFERENCES usuario (id)
)engine InnoDB;

CREATE TABLE extrato (
id INT NOT NULL PRIMARY KEY,
dia DATE,
horario CHAR(5),
valor INT NOT NULL,
tipoMetodo VARCHAR (10),
FOREIGN KEY (id) REFERENCES usuario (id)
)engine InnoDB;

SELECT * FROM usuario;
SELECT * FROM passeProprio;
SELECT * FROM passeAlheio;
SELECT * FROM metodoDePagamento;
SELECT * FROM extrato;
